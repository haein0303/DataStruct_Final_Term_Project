#pragma once

void play_list_main(vector<CList>& playList, vector<MusicData>& data);
void make_dummy_playList(vector<CList>& playList, vector<MusicData>& data);