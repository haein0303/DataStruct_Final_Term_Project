#pragma once

void ChartUI_top();
void ClearUI();
int basicUI();