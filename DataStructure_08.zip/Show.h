#pragma once

void show_search(vector<MusicData>& data);
void show_seach_bst(vector<MusicData>& data);
void showrank(vector<MusicData>& data);